﻿/*
	Este archivo se reemplaza por código específico de la plataforma de la carpeta /merges.
	Más información en http://taco.visualstudio.com/es-es/docs/configure-app/#Content.
*/